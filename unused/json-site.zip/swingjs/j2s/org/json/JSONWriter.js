(function(){var P$=Clazz.newPackage("org.json"),p$1={},I$=[[0,'org.json.JSONObject','java.math.BigDecimal','org.json.JSONArray']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "JSONWriter");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.comma=false;
this.mode='\0';
this.stack=null;
this.top=0;
this.writer=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$Appendable', function (w) {
C$.$init$.apply(this);
this.comma=false;
this.mode="i";
this.stack=Clazz.array($I$(1), [200]);
this.top=0;
this.writer=w;
}, 1);

Clazz.newMeth(C$, 'append$S', function (string) {
if (string == null ) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Null pointer"]);
}if (this.mode == "o" || this.mode == "a" ) {
try {
if (this.comma && this.mode == "a" ) {
this.writer.append$C(",");
}this.writer.append$CharSequence(string);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$Throwable,[e]);
} else {
throw e;
}
}
if (this.mode == "o") {
this.mode="k";
}this.comma=true;
return this;
}throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Value out of sequence."]);
}, p$1);

Clazz.newMeth(C$, 'array$', function () {
if (this.mode == "i" || this.mode == "o"  || this.mode == "a" ) {
p$1.push$org_json_JSONObject.apply(this, [null]);
p$1.append$S.apply(this, ["["]);
this.comma=false;
return this;
}throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Misplaced array."]);
});

Clazz.newMeth(C$, 'end$C$C', function (m, c) {
if (this.mode != m) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,[m == "a" ? "Misplaced endArray." : "Misplaced endObject."]);
}p$1.pop$C.apply(this, [m]);
try {
this.writer.append$C(c);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$Throwable,[e]);
} else {
throw e;
}
}
this.comma=true;
return this;
}, p$1);

Clazz.newMeth(C$, 'endArray$', function () {
return p$1.end$C$C.apply(this, ["a", "]"]);
});

Clazz.newMeth(C$, 'endObject$', function () {
return p$1.end$C$C.apply(this, ["k", "}"]);
});

Clazz.newMeth(C$, 'key$S', function (string) {
if (string == null ) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Null key."]);
}if (this.mode == "k") {
try {
var topObject=this.stack[this.top - 1];
if (topObject.has$S(string)) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Duplicate key \"" + string + "\"" ]);
}topObject.put$S$Z(string, true);
if (this.comma) {
this.writer.append$C(",");
}this.writer.append$CharSequence($I$(1).quote$S(string));
this.writer.append$C(":");
this.comma=false;
this.mode="o";
return this;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$Throwable,[e]);
} else {
throw e;
}
}
}throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Misplaced key."]);
});

Clazz.newMeth(C$, 'object$', function () {
if (this.mode == "i") {
this.mode="o";
}if (this.mode == "o" || this.mode == "a" ) {
p$1.append$S.apply(this, ["{"]);
p$1.push$org_json_JSONObject.apply(this, [Clazz.new_($I$(1))]);
this.comma=false;
return this;
}throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Misplaced object."]);
});

Clazz.newMeth(C$, 'pop$C', function (c) {
if (this.top <= 0) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Nesting error."]);
}var m=this.stack[this.top - 1] == null  ? "a" : "k";
if (m != c) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Nesting error."]);
}this.top-=1;
this.mode=this.top == 0 ? "d" : this.stack[this.top - 1] == null  ? "a" : "k";
}, p$1);

Clazz.newMeth(C$, 'push$org_json_JSONObject', function (jo) {
if (this.top >= 200) {
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Nesting too deep."]);
}this.stack[this.top]=jo;
this.mode=jo == null  ? "a" : "k";
this.top+=1;
}, p$1);

Clazz.newMeth(C$, 'valueToString$O', function (value) {
if (value == null  || value.equals$O(null) ) {
return "null";
}if (Clazz.instanceOf(value, "org.json.JSONString")) {
var object;
try {
object=(value).toJSONString$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('org.json.JSONException').c$$Throwable,[e]);
} else {
throw e;
}
}
if (Clazz.instanceOf(object, "java.lang.String")) {
return object;
}throw Clazz.new_(Clazz.load('org.json.JSONException').c$$S,["Bad value from toJSONString: " + object]);
}if (Clazz.instanceOf(value, "java.lang.Number")) {
var numberAsString=$I$(1).numberToString$Number(value);
try {
var unused=Clazz.new_($I$(2).c$$S,[numberAsString]);
return numberAsString;
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
return $I$(1).quote$S(numberAsString);
} else {
throw ex;
}
}
}if (Clazz.instanceOf(value, "java.lang.Boolean") || Clazz.instanceOf(value, "org.json.JSONObject") || Clazz.instanceOf(value, "org.json.JSONArray")  ) {
return value.toString();
}if (Clazz.instanceOf(value, "java.util.Map")) {
var map=value;
return Clazz.new_($I$(1).c$$java_util_Map,[map]).toString();
}if (Clazz.instanceOf(value, "java.util.Collection")) {
var coll=value;
return Clazz.new_($I$(3).c$$java_util_Collection,[coll]).toString();
}if (value.getClass$().isArray$()) {
return Clazz.new_($I$(3).c$$O,[value]).toString();
}if (Clazz.instanceOf(value, "java.lang.Enum")) {
return $I$(1).quote$S((value).name$());
}return $I$(1).quote$S(value.toString());
}, 1);

Clazz.newMeth(C$, 'value$Z', function (b) {
return p$1.append$S.apply(this, [b ? "true" : "false"]);
});

Clazz.newMeth(C$, 'value$D', function (d) {
return this.value$O(Double.valueOf$D(d));
});

Clazz.newMeth(C$, 'value$J', function (l) {
return p$1.append$S.apply(this, [Long.toString$J(l)]);
});

Clazz.newMeth(C$, 'value$O', function (object) {
return p$1.append$S.apply(this, [C$.valueToString$O(object)]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.06');//Created 2019-01-30 16:37:16 Java2ScriptVisitor version 3.2.4.06 net.sf.j2s.core.jar version 3.2.4.06
