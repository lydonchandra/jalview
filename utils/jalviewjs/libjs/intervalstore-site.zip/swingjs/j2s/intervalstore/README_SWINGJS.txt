BH 2019.10.14

This directory contains all source in intervalstore-vx.x.jar.
No changes are necessary for Jalview (meaning we could use 
the jar file directly for SwingJS with automated decompilation).