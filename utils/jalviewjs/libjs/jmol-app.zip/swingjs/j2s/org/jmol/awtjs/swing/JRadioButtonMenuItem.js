(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JRadioButtonMenuItem", null, 'org.jmol.awtjs.swing.JMenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isRadio=true;
},1);

C$.$fields$=[['Z',['isRadio']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$S$I.apply(this,["rad", 3]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-06-01 14:49:31 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
