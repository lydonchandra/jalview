https://github.com/mikaelgrev/miglayout.git
2018.07.03 BH Latest commit f2a231c
 

Status
======

7/3/2018

no changes necessary

BH 2019.10.14 note:

This directory contains all source in miglayout-4.0-swing.jar.
No changes are necessary for Jalview (meaning we could use 
the jar file directly for SwingJS with automated decompilation).
