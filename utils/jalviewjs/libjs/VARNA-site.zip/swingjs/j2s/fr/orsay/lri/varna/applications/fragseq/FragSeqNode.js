(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications.fragseq"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "FragSeqNode", null, 'javax.swing.tree.DefaultMutableTreeNode');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$O', function (o) {
;C$.superclazz.c$$O.apply(this,[o]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isLeaf$', function () {
return (Clazz.instanceOf(this.getUserObject$(), "fr.orsay.lri.varna.applications.fragseq.FragSeqModel"));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-23 09:06:18 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
