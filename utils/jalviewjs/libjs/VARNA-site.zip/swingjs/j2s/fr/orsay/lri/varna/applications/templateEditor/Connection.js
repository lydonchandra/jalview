(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications.templateEditor"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Connection");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['_h1','fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement','_edge1','fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement.RelativePosition','_h2','fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement','_edge2','fr.orsay.lri.varna.applications.templateEditor.GraphicalTemplateElement.RelativePosition']]]

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement$fr_orsay_lri_varna_applications_templateEditor_GraphicalTemplateElement_RelativePosition', function (h1, edge1, h2, edge2) {
;C$.$init$.apply(this);
this._h1=h1;
this._h2=h2;
this._edge1=edge1;
this._edge2=edge2;
}, 1);

Clazz.newMeth(C$, 'equals$fr_orsay_lri_varna_applications_templateEditor_Connection', function (c) {
return ((this._h1 === c._h1 ) && (this._h2 === c._h2 ) && (this._edge1 === c._edge1 ) && (this._edge2 === c._edge2 )  );
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-23 09:06:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
