(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.naView"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Radloop");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['radius'],'I',['loopnumber'],'O',['next','fr.orsay.lri.varna.models.naView.Radloop','+prev']]]

Clazz.newMeth(C$, 'getRadius$', function () {
return this.radius;
});

Clazz.newMeth(C$, 'setRadius$D', function (radius) {
this.radius=radius;
});

Clazz.newMeth(C$, 'getLoopnumber$', function () {
return this.loopnumber;
});

Clazz.newMeth(C$, 'setLoopnumber$I', function (loopnumber) {
this.loopnumber=loopnumber;
});

Clazz.newMeth(C$, 'getNext$', function () {
return this.next;
});

Clazz.newMeth(C$, 'setNext$fr_orsay_lri_varna_models_naView_Radloop', function (next) {
this.next=next;
});

Clazz.newMeth(C$, 'getPrev$', function () {
return this.prev;
});

Clazz.newMeth(C$, 'setPrev$fr_orsay_lri_varna_models_naView_Radloop', function (prev) {
this.prev=prev;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-23 09:06:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
