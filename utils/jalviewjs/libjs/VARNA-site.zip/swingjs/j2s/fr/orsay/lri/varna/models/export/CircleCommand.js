(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "CircleCommand", null, 'fr.orsay.lri.varna.models.export.GraphicElement');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['_radius','_thickness'],'O',['_base','java.awt.geom.Point2D.Double']]]

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$D$D', function (base, radius, thickness) {
Clazz.super_(C$, this);
this._base=base;
this._radius=radius;
this._thickness=thickness;
}, 1);

Clazz.newMeth(C$, 'get_base$', function () {
return this._base;
});

Clazz.newMeth(C$, 'get_radius$', function () {
return this._radius;
});

Clazz.newMeth(C$, 'get_thickness$', function () {
return this._thickness;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-23 09:06:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
