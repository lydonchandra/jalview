(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TextCommand", null, 'fr.orsay.lri.varna.models.export.GraphicElement');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['_txt'],'O',['_base','java.awt.geom.Point2D.Double']]]

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$S', function (base, txt) {
Clazz.super_(C$, this);
this._base=base;
this._txt=txt;
}, 1);

Clazz.newMeth(C$, 'get_base$', function () {
return this._base;
});

Clazz.newMeth(C$, 'get_txt$', function () {
return this._txt;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-23 09:06:21 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
