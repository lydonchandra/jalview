BH 2019.05.15

Note that this version of VARNA is from https://github.com/BobHanson/VARNA

BH 2019.10.14

Code is from https://github.com/BobHanson/VARNA and DOES have
changes specific to SwingJS involving dialogs and file loading.

The Varna jar file CANNOT be used directly via decompilation.
